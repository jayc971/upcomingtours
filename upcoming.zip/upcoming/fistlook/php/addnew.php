


<?php
	session_start();
	
	if(isset($_SESSION['uname'])){
		
		require_once('../db/connect.php');
		

		
		
		// print_r($_POST);
		

		if(isset($_POST) & !empty($_POST)){
		
		$bname = mysqli_real_escape_string($connection, $_POST['bname']);
		$byear = mysqli_real_escape_string($connection, $_POST['byear']);
		$bprice = mysqli_real_escape_string($connection, $_POST['bprice']);
		$bisbn = mysqli_real_escape_string($connection, $_POST['bisbn']);
		$bmedium = mysqli_real_escape_string($connection, $_POST['bmedium']);
		
		$bauthor = mysqli_real_escape_string($connection, $_POST['bauthor']);
		
		$bcategory = mysqli_real_escape_string($connection, $_POST['bcategory']);

		
		$createsql1 = "INSERT INTO `tblbooks` (name, year, price, isbn, medium) VALUES ('$bname', '$byear', '$bprice', '$bisbn', '$bmedium')";
		
		$createsql2 = "INSERT INTO `tblauthors` (author) VALUES ('$bauthor')";
		
		$createsql3 = "INSERT INTO `tblcategories` (category) VALUES ('$bcategory')";
		
		$res1 = mysqli_query($connection, $createsql1);
		
		$res2 = mysqli_query($connection, $createsql2);
		
		$res3 = mysqli_query($connection, $createsql3);
		
		if ($res1 || $res2 || $res3){

			
			echo "<span><div id='success-alert' class='alert alert-success'>";
			echo "<strong>Success!</strong> data inserted successfully. You will be redirected to dashboard!";
			echo "</div></span>";
			header( "refresh:2;url=../db/dashboard.php" );
			
			
		}else{
			echo "<span><div id='success-alert' class='alert alert-warning'>";
			echo "<strong>Failed!</strong> Failed to insert data";
			echo "</div></span>";
			

	


		}
		
		
		
		
		
		
		
	
		
		
		}
		
	

		
		
		
		
		
		
		
		
echo "<html>";
echo "<head>";



echo "<title>pomegranate</title>";
	
echo "<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css' integrity='sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u' crossorigin='anonymous'>";



echo "<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js' integrity='sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa' crossorigin='anonymous'></script>";



	
echo "</head>";
echo "<body>";



		//echo "<h2>Welcome to JBooks databse !</h2>";
		
		//echo "<br><a href='permit.php'><input type=button name=back value=back></a>";

		echo "<br><a href='../db/dashboard.php'><input type=button name=dashboard value=dashboard></a>";
		
		echo "<p style='margin-top:-10px; margin-bottom:-5px;'></p>";
		
		echo "<br><a href='../php/logout.php'><input type=button name=logout value=logout></a>";
		
	



echo "<div class='container'>";
echo "<div class='row'>";
echo "<form method='post' class='form-horizontal col-md-7 col-md-offset-2'>";
			
echo "<h2 align='center'>add new data</h2>";
				
echo "<div class='form-group'>";
echo "<label for='input1' class='col-sm-2 control-label'>Name</label>";
echo "<div class='col-sm-10'>";
echo "<input type='text' name='bname' class='form-control' id='bname' placeholder='Name'/>";
echo "</div>";
echo "</div>";
					
					
echo "<div class='form-group'>";
echo "<label for='input1' class='col-sm-2 control-label'>Author</label>";
echo "<div class='col-sm-10'>";
echo "<input type='text' name='bauthor' class='form-control' id='bauthor' placeholder='Author'/>";
echo "</div>";
echo "</div>";
					
					
echo "<div class='form-group'>";
echo "<label for='input1' class='col-sm-2 control-label'>Year of Publish</label>";
echo "<div class='col-sm-10'>";
echo "<input type='text' name='byear' class='form-control' id='byear' placeholder='Year of Publish'/>";
echo "</div>";
echo "</div>";
					
			
					
					
echo "<div class='form-group'>";
echo "<label for='input1' class='col-sm-2 control-label'>Price</label>";
echo "<div class='col-sm-10'>";
echo "<input type='text' name='bprice' class='form-control' id='bprice' placeholder='Price'/>";
echo "</div>";
echo "</div>";
					
					



echo "<div class='form-group'>";
echo "<label for='input1' class='col-sm-2 control-label'>ISBN</label>";
echo "<div class='col-sm-10'>";
echo "<input type='text' name='bisbn' class='form-control' id='bisbn' placeholder='ISBN'/>";
echo "</div>";
echo "</div>";






echo "<div class='form-group'>";
echo "<label for='input1' class='col-sm-2 control-label'>Medium</label>";
echo "<div class='col-sm-10'>";
echo "<input type='text' name='bmedium' class='form-control' id='bmedium' placeholder='Medium'/>";
echo "</div>";
echo "</div>";






echo "<div class='form-group'>";
echo "<label for='input1' class='col-sm-2 control-label'>Image</label>";
echo "<div class='col-sm-10'>";

echo "<input type='file' name='bimage' class='form-control' id='bimage' placeholder='Image'/>";

echo "</div>";
echo "</div>";





echo "<div class='form-group'>";
echo "<label for='input1' class='col-sm-2 control-label'>Age</label>";
echo "<div class='col-sm-10'>";
echo "<select name='bcategory' id='bcategory' class='form-control'>";
echo "<option>Category</option>";
echo "<option value='fictional'>fictional</option>";
echo "<option value='novel'>novel</option>";
echo "<option value='documentry'>documentry</option>";
echo "<option value='short stories'>short stories</option>";
echo "<option value='dictionary'>dictionary</option>";
echo "</select>";
echo "</div>";
echo "</div>";






					
echo "<input type='submit' class='btn btn-primary col-md-2 col-md-offset-10' value='add this data'/>";
					
echo "</form>";
echo "</div>";
echo "</div>";
echo "</body>";
echo "</html>";



		}
		
		
		else {
		
		echo "<script>location.href='../index.php'</script>";
	
	
	}
	
	
?>

