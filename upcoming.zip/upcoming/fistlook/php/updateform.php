


<?php
	session_start();
	
	if(isset($_SESSION['uname'])){
		
		require_once('../db/connect.php');
		
		$id = $_GET['id'];
		
		$selectsql = "SELECT * FROM `tblbooks` WHERE id=$id";
		$selectsql2 = "SELECT * FROM `tblauthors` WHERE id=$id";
		$selectsql3 = "SELECT * FROM `tblcategories` WHERE id=$id";
		
		$res = mysqli_query($connection, $selectsql);
		$res2 = mysqli_query($connection, $selectsql2);
		$res3 = mysqli_query($connection, $selectsql3);
		
		$r = mysqli_fetch_assoc($res);
		$r2 = mysqli_fetch_assoc($res2);
		$r3 = mysqli_fetch_assoc($res3);
		
		// print_r($_POST);
		

		if(isset($_POST) & !empty($_POST)){
		
		$bname = mysqli_real_escape_string($connection, $_POST['bname']);
		$byear = mysqli_real_escape_string($connection, $_POST['byear']);
		$bprice = mysqli_real_escape_string($connection, $_POST['bprice']);
		$bisbn = mysqli_real_escape_string($connection, $_POST['bisbn']);
		$bmedium = mysqli_real_escape_string($connection, $_POST['bmedium']);
		
		$bauthor = mysqli_real_escape_string($connection, $_POST['bauthor']);
		
		$bcategory = mysqli_real_escape_string($connection, $_POST['bcategory']);

		$updatesql1 = "UPDATE `tblbooks` SET name='$bname', year='$byear', price='$bprice', isbn='$bisbn', medium='$bmedium' WHERE id=$id";
		
		$updatesql2 = "UPDATE `tblauthors` SET author='$bauthor' WHERE id=$id";
		
		$updatesql3 = "UPDATE `tblcategories` SET category='$bcategory' WHERE id=$id";
		
		
		$res = mysqli_query($connection, $updatesql1);
		
		$res2 = mysqli_query($connection, $updatesql2);
		
		$res3 = mysqli_query($connection, $updatesql3);
		
		if ($res || $res2 || $res3){

			echo "<span><div id='success-alert' class='alert alert-success'>";
			echo "<strong>Success!</strong> data inserted successfully. You will be redirected to dashboard!";
			echo "</div></span>";
			header( "refresh:2;url=../db/dashboard.php" );
				

		}else{
			echo "<span><div id='success-alert' class='alert alert-warning'>";
			echo "<strong>Failed!</strong> Failed to insert data";
			echo "</div></span>";
			

	


		}
		
		
	
		
		
		}
		
	

		
		
		
		
		
		
		
		
echo "<html>";
echo "<head>";



echo "<title>pomegranate</title>";
	
echo "<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css' integrity='sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u' crossorigin='anonymous'>";



echo "<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js' integrity='sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa' crossorigin='anonymous'></script>";



	
echo "</head>";
echo "<body>";



		//echo "<h2>Welcome to JBooks databse !</h2>";
		
		//echo "<br><a href='permit.php'><input type=button name=back value=back></a>";

		echo "<br><a href='../db/dashboard.php'><input type=button name=dashboard value=dashboard></a>";
		
		echo "<p style='margin-top:-10px; margin-bottom:-5px;'></p>";
		
		echo "<br><a href='../php/logout.php'><input type=button name=logout value=logout></a>";
		
	



echo "<div class='container'>";
echo "<div class='row'>";
echo "<form method='post' class='form-horizontal col-md-7 col-md-offset-2'>";
			
echo "<h2 align='center'>Update Data</h2>";
				
echo "<div class='form-group'>";
echo "<label for='input1' class='col-sm-2 control-label'>Name</label>";
echo "<div class='col-sm-10'>";
echo "<input type='text' name='bname' class='form-control' id='bname' value=$r[name] placeholder='Name'/>";
echo "</div>";
echo "</div>";
					
					
echo "<div class='form-group'>";
echo "<label for='input1' class='col-sm-2 control-label'>Author</label>";
echo "<div class='col-sm-10'>";
echo "<input type='text' name='bauthor' class='form-control' id='bauthor' value=$r2[author] placeholder='Author'/>";
echo "</div>";
echo "</div>";
					
					
echo "<div class='form-group'>";
echo "<label for='input1' class='col-sm-2 control-label'>Year of Publish</label>";
echo "<div class='col-sm-10'>";
echo "<input type='text' name='byear' class='form-control' id='byear' value=$r[year] placeholder='Year of Publish'/>";
echo "</div>";
echo "</div>";
					
			
					
					
echo "<div class='form-group'>";
echo "<label for='input1' class='col-sm-2 control-label'>Price</label>";
echo "<div class='col-sm-10'>";
echo "<input type='text' name='bprice' class='form-control' id='bprice' value=$r[price] placeholder='Price'/>";
echo "</div>";
echo "</div>";
					





echo "<div class='form-group'>";
echo "<label for='input1' class='col-sm-2 control-label'>ISBN</label>";
echo "<div class='col-sm-10'>";
echo "<input type='text' name='bisbn' class='form-control' id='bisbn' value=$r[isbn] placeholder='ISBN'/>";
echo "</div>";
echo "</div>";






echo "<div class='form-group'>";
echo "<label for='input1' class='col-sm-2 control-label'>Medium</label>";
echo "<div class='col-sm-10'>";
echo "<input type='text' name='bmedium' class='form-control' id='bmedium' value=$r[medium] placeholder='Medium'/>";
echo "</div>";
echo "</div>";






echo "<div class='form-group'>";
echo "<label for='input1' class='col-sm-2 control-label'>Image</label>";
echo "<div class='col-sm-10'>";

echo "<input type='file' name='bimage' class='form-control' id='bimage' value=$r[image] placeholder='Image'/>";

echo "</div>";
echo "</div>";




$iffictional = '';
$ifnovel = '';
$ifdocumentry = '';
$ifshortstories = '';
$ifdictionary = '';

if($r3['category']=='fictional'){
	
	$iffictional = 'selected';
	$ifnovel = '';
	$ifdocumentry = '';
	$ifshortstories = '';
	$ifdictionary = '';
	
}elseif ($r3['category']=='novel') {
	
	$iffictional = '';
	$ifnovel = 'selected';
	$ifdocumentry = '';
	$ifshortstories = '';
	$ifdictionary = '';
	
}elseif ($r3['category']=='documentry') {
	
	$iffictional = '';
	$ifnovel = '';
	$ifdocumentry = 'selected';
	$ifshortstories = '';
	$ifdictionary = '';
	
}elseif ($r3['category']=='short stories') {
	
	$iffictional = '';
	$ifnovel = '';
	$ifdocumentry = '';
	$ifshortstories = 'selected';
	$ifdictionary = '';
	
}else {
	
	$iffictional = '';
	$ifnovel = '';
	$ifdocumentry = '';
	$ifshortstories = '';
	$ifdictionary = 'selected';
	
}


echo "<div class='form-group'>";
echo "<label for='input1' class='col-sm-2 control-label'>Category</label>";
echo "<div class='col-sm-10'>";
echo "<select name='bcategory' id='bcategory' class='form-control'>";
echo "<option>Category</option>";


$iffictional = "<option value='fictional' $iffictional>fictional</option>";
eval( "\$iffictional = \"$iffictional\";" );
echo $iffictional;


$ifnovel = "<option value='novel' $ifnovel>novel</option>";
eval( "\$ifnovel = \"$ifnovel\";" );
echo $ifnovel;


$ifdocumentry = "<option value='documentry' $ifdocumentry>documentry</option>";
eval( "\$ifdocumentry = \"$ifdocumentry\";" );
echo $ifdocumentry;


$ifshortstories = "<option value='short stories' $ifshortstories>short stories</option>";
eval( "\$ifshortstories = \"$ifshortstories\";" );
echo $ifshortstories;


$ifdictionary = "<option value='dictionary' $ifdictionary>dictionary</option>";
eval( "\$ifdictionary = \"$ifdictionary\";" );
echo $ifdictionary;


echo "</select>";
echo "</div>";
echo "</div>";






					
echo "<input type='submit' class='btn btn-primary col-md-2 col-md-offset-10' value='Update'/>";
					
echo "</form>";
echo "</div>";
echo "</div>";
echo "</body>";
echo "</html>";



		}
		
		
		else {
		
		echo "<script>location.href='../index.php'</script>";
	
	
	}
	
	
?>

