<?php
require_once('connect.php');
$id = $_GET['id'];
$deletesql1 = "DELETE FROM `tblbooks` WHERE id=$id";
$deletesql2 = "DELETE FROM `tblauthors` WHERE id=$id";

$res1 = mysqli_query($connection, $deletesql1);
$res2 = mysqli_query($connection, $deletesql2);

if ($res1 || $res2){
	
	header('location: dashboard.php');
	
}else{

echo "Failed to delete record";

}

?>