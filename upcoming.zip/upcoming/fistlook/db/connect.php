<?php
$connection = mysqli_connect('localhost','root','');



if(!$connection){
	die("Database connection failed" . mysql_error($connection));
}

$selectdb = mysqli_select_db($connection,'pomegranate');

if(!$selectdb){
	die("Database selection failed" . mysql_error($connection));
}

?>